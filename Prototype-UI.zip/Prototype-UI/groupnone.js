var main = function() {
	"use strict";
  $(".toggle-off").click(function() {
		$(this).toggleClass('on');

  });
};

$(document).ready(main);