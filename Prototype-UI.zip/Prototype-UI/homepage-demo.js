var main = function () {
	"use strict";
	$('.drawer').click(function() {
		$('.interface').animate(
			{left: '0px'}, 200);
		$('.drawer-box').animate(
			{left: '200px'}, 200);
	});
	
};

$(document).ready(main);